import './App.css';
import YouTube from "react-youtube";
import { Getmusiclist, searchMusic } from './api'
import { useEffect, useState } from 'react'
const App = () => {
  const [indexmusic, setindexmusic] = useState([])
  useEffect(() => {
    Getmusiclist().then((response) => {
      setindexmusic(response)
    })
  }, [])


  const Listmusic = () => {
    return indexmusic.map((musick, i) => {
      return (
        <div className="Music-wrapper" key={i}>
          <div className="Music-title"> {musick.title} </div>
          <img className="Music-image" src={musick.image} />
          <div className="Music-durasi">{musick.timestamp} </div>
        </div>
      )
    })
  }
  const search = async (q) => {
    if (q.length > 3) {
      const cari = await searchMusic(q)
      setindexmusic(cari.hasil)
    }
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>Music Search</h1>
        <input
          placeholder="Cari music"
          className="Music-search"
          onChange={({ target }) => search(target.value)}
        />
        <div className="Music-container">
          <Listmusic />
        </div>
      </header >
    </div >
  );
}

export default App;
