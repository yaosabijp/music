import axios from 'axios'

export const Getmusiclist = async () => {
    const music = await axios.get(`https://apimu.my.id/search/youtube?query=komando%20tanjiro`)
    return music.data.hasil
}

export const searchMusic = async (q) => {
    const search = await axios.get(`https://apimu.my.id/search/youtube?query=${q}`)
    return search.data
}